/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ASUS
 */
public class ListaPrioridadDobleCircular {
    private NodoDobleP ini;
    private NodoDobleP fin;
    
    public ListaPrioridadDobleCircular(){
        ini=fin=null;
    }
    
    public boolean insertar(char dato, int prioridad){
        NodoDobleP nuevo = new NodoDobleP(dato,prioridad);
        if(nuevo==null) return false;
        if(ListaDobleVacia()){
            ini=fin=nuevo;
            ini.setAnt(fin);
            fin.setSig(ini);
            return true;
        }
         if(nuevo.prioridad>ini.prioridad){
            ini.ant=nuevo;
            nuevo.sig=ini;
            nuevo.ant=fin;
            ini=nuevo;
            return true;
        }
        if(nuevo.prioridad<=fin.prioridad){
            fin.ant=nuevo;
            nuevo.ant=fin;
            nuevo.sig=ini;
            fin=nuevo;
            return true;
        }
        
        return true;
    }
    
    public boolean eliminar(){
        if(ListaDobleVacia())return false;
        if(unSoloNodo()){
            ini.setAnt(null);
            fin.setSig(null);
            ini=fin=null;
            return true;
        }
        NodoDobleP temp=ini;
        ini=temp.getSig();
        ini.setAnt(null);
        temp.setSig(null);
        ini.setAnt(fin);
        fin.setSig(ini);
        temp.setAnt(null);
        temp=null;
        return true;
    }
    
    public boolean ListaDobleVacia(){
        return ini==null && fin==null;
    }
    
     public boolean unSoloNodo(){
        return ini==fin;
    }

    NodoDobleP getIni() {
        return ini;
    }
}
